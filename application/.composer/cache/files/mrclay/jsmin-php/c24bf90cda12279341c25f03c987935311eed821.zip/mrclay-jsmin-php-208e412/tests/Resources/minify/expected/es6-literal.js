`line
break`+`he  llo`;foo`hel( '');lo`;`he\nl\`lo`;(`he${one + two}`)