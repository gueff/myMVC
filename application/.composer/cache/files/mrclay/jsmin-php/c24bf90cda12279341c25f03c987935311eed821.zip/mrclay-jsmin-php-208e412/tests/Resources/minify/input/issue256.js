!function(){}(window)

!function(){}(window)