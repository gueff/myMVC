<?php

namespace JSMin;

class UnterminatedCommentException extends \Exception {
}
