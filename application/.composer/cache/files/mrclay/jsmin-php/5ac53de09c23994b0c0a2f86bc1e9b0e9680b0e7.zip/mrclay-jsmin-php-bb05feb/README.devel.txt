The following steps can be performed to setup a development environment.

Download composer.phar as described at https://getcomposer.org/download/

Execute composer:
  php composer.phar update

Execute phpunit tests:
  ./vendor/bin/phpunit

