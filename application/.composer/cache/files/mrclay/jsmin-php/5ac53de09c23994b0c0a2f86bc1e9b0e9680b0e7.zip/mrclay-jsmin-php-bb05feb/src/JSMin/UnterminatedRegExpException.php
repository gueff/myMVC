<?php

namespace JSMin;

class UnterminatedRegExpException extends \Exception {
}
