!function(){return xreturn/foo}();

!function(){return xtypeof/foo}();
