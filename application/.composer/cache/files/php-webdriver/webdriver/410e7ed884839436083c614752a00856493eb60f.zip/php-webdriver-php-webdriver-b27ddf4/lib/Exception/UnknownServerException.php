<?php

namespace Facebook\WebDriver\Exception;

/**
 * @deprecated Use Facebook\WebDriver\Exception\UnknownErrorException
 */
class UnknownServerException extends UnknownErrorException
{
}
