<?php

namespace Facebook\WebDriver\Exception;

class WebDriverCurlException extends WebDriverException
{
}
