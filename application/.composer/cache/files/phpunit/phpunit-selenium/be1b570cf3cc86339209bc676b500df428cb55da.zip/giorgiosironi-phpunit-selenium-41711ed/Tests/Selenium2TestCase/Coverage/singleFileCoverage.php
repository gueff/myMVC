<?php
$_GET['PHPUNIT_SELENIUM_TEST_ID'] = $argv[1];
require __DIR__ . '/../../../PHPUnit/Extensions/SeleniumCommon/phpunit_coverage.php';
